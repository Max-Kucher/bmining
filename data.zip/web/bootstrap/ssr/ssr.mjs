import "react-dom/server";
import "@inertiajs/react";
import "@inertiajs/react/server";
(function() {
  for (var t = [], r = 0; r < 256; ++r)
    t.push("%" + ((r < 16 ? "0" : "") + r.toString(16)).toUpperCase());
  return t;
})();
