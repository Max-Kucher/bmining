<?php

namespace App\Enums\Withdrawal;

enum WithdrawalType
{
    const BTC = 'btc';
}
