<?php

namespace App\Enums;

enum AddressType: string
{
    const BTC = 'btc';
    const LTC = 'ltc';
}
