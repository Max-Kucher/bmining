<?php

namespace App\Enums;

enum EventTypes
{
    const USER_TASK = 'user_task';
}
