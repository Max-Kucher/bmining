<?php

namespace App\Enums;

enum Currency: string
{
    const BTC = 'btc';
    const LTC = 'ltc';
}
