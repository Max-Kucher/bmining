<?php

namespace App\Enums;

use App\Models\CryptoPayment;

enum PaymentsType: string
{
    const CRYPTO = 'crypto_payments';
}
