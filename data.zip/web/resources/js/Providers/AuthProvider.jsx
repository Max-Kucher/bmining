import {useNavigate} from "react-router-dom";

export function AuthProvider({children}) {
    const navigate = useNavigate();

    return (
        <>
        </>
    );
}
