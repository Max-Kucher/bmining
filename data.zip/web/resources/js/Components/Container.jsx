export default function Container({children}) {
    return <>
        {children}
    </>;
}
