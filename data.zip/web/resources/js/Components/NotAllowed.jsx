export const NotAllowed = () => {
    return (<>
        <div style={{display: 'flex', justifyContent: 'center'}}>
            <h2>Access denied</h2>
        </div>
    </>);
};
