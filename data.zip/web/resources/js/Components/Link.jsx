export function Link({href, children}) {
    return <Link to={href}>
        {children}
    </Link>
}
