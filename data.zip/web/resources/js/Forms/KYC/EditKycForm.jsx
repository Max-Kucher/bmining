export default function EditKycForm({kyc = null}) {
    return (<>
        <p>asd</p>
        {/*<p>{JSON.stringify(kyc)}</p>*/}
    </>);
}
